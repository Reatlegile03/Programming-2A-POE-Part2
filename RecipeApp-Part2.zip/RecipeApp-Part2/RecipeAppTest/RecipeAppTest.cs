using RecipeApp_Part2;

namespace RecipeAppTest
{
    [TestClass]
    public class RecipeAppTest
    {
        [TestMethod]
        public void CalculateTotalCalories()
        {
            // Arrange
            var ingredients = new List<Ingredient>
        {
            new Ingredient { Name = "Ingredient1", Quantity = 100, Calories = 50 },
            new Ingredient { Name = "Ingredient2", Quantity = 200, Calories = 25 },
            new Ingredient { Name = "Ingredient3", Quantity = 150, Calories = 30 }
        };

            var recipe = new Recipe { Ingredients = ingredients };

            // Act
            double totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(17500, totalCalories); // 100*50 + 200*25 + 150*30 = 5000 + 5000 + 4500 = 17500
        }
    }

}
    
