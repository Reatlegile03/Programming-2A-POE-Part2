﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecipeApp_Part2
{
    public class Ingredient
    {
        public string Name { get; set; }
        private double _quantity;
        public double Quantity
        {
            get { return _quantity; }
            set
            {
                if (value >= 0)
                    _quantity = value;
                else
                    throw new ArgumentException("Quantity cannot be negative.");
            }
        }

        private double _originalQuantity;
        public double OriginalQuantity
        {
            get { return _originalQuantity; }
            set
            {
                if (value >= 0)
                    _originalQuantity = value;
                else
                    throw new ArgumentException("Original quantity cannot be negative.");
            }
        }

        public string Unit { get; set; }

        private double _calories;
        public double Calories
        {
            get { return _calories; }
            set
            {
                if (value >= 0)
                    _calories = value;
                else
                    throw new ArgumentException("Calories cannot be negative.");
            }
        }

        public string FoodGroup { get; set; }

        // Default constructor
        public Ingredient()
        {
        }

        // Constructor with parameters
        public Ingredient(string name, double quantity, double originalQuantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            OriginalQuantity = originalQuantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }
    }
}
