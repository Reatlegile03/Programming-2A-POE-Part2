﻿using RecipeApp_Part2;

public class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Recipe App!");
        

        var recipes = new List<Recipe>();
        bool exit = false;

        while (!exit)
        {
            Console.WriteLine("\nOptions:");
            Console.WriteLine("1. Add Recipe");
            Console.WriteLine("2. Display All Recipes");
            Console.WriteLine("3. Display Recipe");
            Console.WriteLine("4. Scale Recipe");
            Console.WriteLine("5. Reset Quantities");
            Console.WriteLine("6. Clear A Recipe");
            Console.WriteLine("7. Exit");
            Console.Write("Enter your Option: ");

            int choice;
            if (!int.TryParse(Console.ReadLine(), out choice))
            {
                Console.WriteLine("Invalid choice. Please try again.");
                continue;
            }

            switch (choice)
            {
                case 1:
                    var recipe = new Recipe();
                    recipe.EnterDetails();
                    recipes.Add(recipe);
                    break;
                case 2:
                    Console.WriteLine("Recipes:");

                    if (recipes.Count == 0)
                    {
                        Console.WriteLine("No recipes entered yet.");
                    }
                    else
                    {
                        foreach (var r in recipes)
                        {
                            Console.WriteLine(r.Name);
                        }
                    }
                    break;
                case 3:
                    Console.Write("Enter the name of the recipe to display: ");
                    string recipeName = Console.ReadLine();
                    var selectedRecipe = recipes.Find(r => r.Name.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
                    if (selectedRecipe != null)
                    {
                        selectedRecipe.Display();
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 4:
                    Console.Write("Enter the name of the recipe to scale: ");
                    string recipeToScale = Console.ReadLine();
                    var recipeToScaleObj = recipes.Find(r => r.Name.Equals(recipeToScale, StringComparison.OrdinalIgnoreCase));
                    if (recipeToScaleObj != null)
                    {
                        bool validScaleFactorEntered = false;

                        while (!validScaleFactorEntered)
                        {
                            Console.Write("Enter scale factor (0.5, 2, or 3): ");
                            double scaleFactor;
                            if (double.TryParse(Console.ReadLine(), out scaleFactor) &&
                                (scaleFactor == 0.5 || scaleFactor == 2 || scaleFactor == 3))
                            {
                                recipeToScaleObj.Scale(scaleFactor);
                                validScaleFactorEntered = true;
                            }
                            else
                            {
                                Console.WriteLine("Invalid scale factor. Please enter 0.5, 2, or 3.");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 5:
                    Console.Write("Enter the name of the recipe to reset quantities: ");
                    string recipeToReset = Console.ReadLine();
                    var recipeToResetObj = recipes.Find(r => r.Name.Equals(recipeToReset, StringComparison.OrdinalIgnoreCase));
                    if (recipeToResetObj != null)
                    {
                        recipeToResetObj.ResetQuantities();
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 6:
                    Console.Write("Enter the name of the recipe to clear data: ");
                    string recipeToClear = Console.ReadLine();
                    var recipeToClearObj = recipes.Find(r => r.Name.Equals(recipeToClear, StringComparison.OrdinalIgnoreCase));
                    if (recipeToClearObj != null)
                    {
                        recipeToClearObj.ClearData();
                        recipes.Remove(recipeToClearObj); // Remove the cleared recipe from the list
                    }
                    else
                    {
                        Console.WriteLine("Recipe not found!");
                    }
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }
        }

        Console.WriteLine("\nThank you for using the Recipe App!");
    }
}
    
